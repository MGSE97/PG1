#include "stdafx.h"
#include "mymath.h"
